import React from 'react';
import { 
  BookOpen, 
  Users, 
  CheckCircle, 
  ArrowRight, 
  MessageCircle, 
  Clock, 
  Bell, 
  Smartphone,
  Star,
  User,
  ExternalLink,
  Zap,
  Shield,
  Heart
} from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-[#000e3f] text-white font-inter">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#000e3f] via-[#001454] to-[#000e3f]"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24">
          <div className="text-center">
            {/* Logo Placeholder */}
            <div className="mb-8">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/20 mb-6">
                <BookOpen className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-6xl sm:text-7xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent mb-4">
                TECHDAIRY
              </h1>
            </div>
            
            <h2 className="text-4xl sm:text-6xl font-bold mb-6 leading-tight">
              Digitize Your School
            </h2>
            
            <p className="text-xl sm:text-2xl text-blue-100 mb-8 max-w-4xl mx-auto leading-relaxed">
              Goodbye lost diaries, missed homework & disconnected parents. 
              <br className="hidden sm:block" />
              Techdairy brings all communication into one smart app.
            </p>
            
            <a 
              href="https://wa.me/message/6ROBRBS4JHVMM1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <MessageCircle className="w-6 h-6 mr-3" />
              Book a Free Demo Now
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </div>
        </div>
      </section>

      {/* Problem Solved Block */}
      <section className="py-20 bg-gradient-to-b from-[#000e3f] to-[#001454]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold mb-8">
              Sound Familiar?
            </h3>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-6">
                <MessageCircle className="w-8 h-8 text-red-400" />
              </div>
              <h4 className="text-xl font-semibold mb-4 text-red-100">
                "Tired of parents calling about homework?"
              </h4>
              <p className="text-blue-200">
                Constant phone calls disrupting your day because parents can't find homework details in messy diaries.
              </p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300">
              <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mb-6">
                <Clock className="w-8 h-8 text-yellow-400" />
              </div>
              <h4 className="text-xl font-semibold mb-4 text-yellow-100">
                "Do teachers waste time writing homework in diaries?"
              </h4>
              <p className="text-blue-200">
                Teachers spending precious time writing the same homework in 30+ diaries every single day.
              </p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300">
              <div className="w-16 h-16 bg-orange-500/20 rounded-full flex items-center justify-center mb-6">
                <Users className="w-8 h-8 text-orange-400" />
              </div>
              <h4 className="text-xl font-semibold mb-4 text-orange-100">
                "Do students forget tasks too often?"
              </h4>
              <p className="text-blue-200">
                Students losing diaries, forgetting homework, and parents having no way to track their child's progress.
              </p>
            </div>
          </div>
          
          <div className="text-center">
            <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full text-white font-semibold text-lg">
              <Zap className="w-6 h-6 mr-2" />
              Solve all these with one app: Techdairy
            </div>
          </div>
        </div>
      </section>

      {/* Why Techdairy - Benefits */}
      <section className="py-20 bg-[#001454]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold mb-4">
              Why Techdairy?
            </h3>
            <p className="text-xl text-blue-200">Benefits for Everyone in Your School</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 rounded-xl p-8 border border-purple-500/20 hover:border-purple-400/40 transition-all duration-300 group">
              <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <BookOpen className="w-8 h-8 text-purple-400" />
              </div>
              <h4 className="text-2xl font-bold mb-4 text-purple-100">📘 For Teachers</h4>
              <p className="text-lg text-blue-200 mb-4">Assign tasks in just 2 taps.</p>
              <ul className="text-blue-300 space-y-2">
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> No more writing in diaries</li>
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Instant delivery to all students</li>
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Track completion status</li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-br from-green-500/10 to-green-600/5 rounded-xl p-8 border border-green-500/20 hover:border-green-400/40 transition-all duration-300 group">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Users className="w-8 h-8 text-green-400" />
              </div>
              <h4 className="text-2xl font-bold mb-4 text-green-100">🧑‍🎓 For Students</h4>
              <p className="text-lg text-blue-200 mb-4">Never forget homework again.</p>
              <ul className="text-blue-300 space-y-2">
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Smart reminders</li>
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Organized task lists</li>
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Easy submission tracking</li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-br from-blue-500/10 to-cyan-600/5 rounded-xl p-8 border border-blue-500/20 hover:border-blue-400/40 transition-all duration-300 group">
              <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Heart className="w-8 h-8 text-blue-400" />
              </div>
              <h4 className="text-2xl font-bold mb-4 text-blue-100">👨‍👩‍👧 For Parents</h4>
              <p className="text-lg text-blue-200 mb-4">Stay updated on their child's progress in real-time.</p>
              <ul className="text-blue-300 space-y-2">
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Instant notifications</li>
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Progress tracking</li>
                <li className="flex items-center"><CheckCircle className="w-4 h-4 mr-2 text-green-400" /> Direct teacher communication</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gradient-to-b from-[#001454] to-[#000e3f]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl sm:text-4xl font-bold mb-4">
              How It Works
            </h3>
            <p className="text-xl text-blue-200">Simple. Smart. Instant.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold text-white group-hover:scale-110 transition-transform duration-300">
                1
              </div>
              <h4 className="text-xl font-semibold mb-4">Teacher enters homework</h4>
              <p className="text-blue-200">Teacher types homework once in the app - takes just 30 seconds</p>
            </div>
            
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-cyan-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold text-white group-hover:scale-110 transition-transform duration-300">
                2
              </div>
              <h4 className="text-xl font-semibold mb-4">Students see it instantly</h4>
              <p className="text-blue-200">All students in the class receive the homework immediately on their phones</p>
            </div>
            
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold text-white group-hover:scale-110 transition-transform duration-300">
                3
              </div>
              <h4 className="text-xl font-semibold mb-4">Parents are notified automatically</h4>
              <p className="text-blue-200">Parents get notifications and can track their child's homework progress</p>
            </div>
          </div>
        </div>
      </section>

      {/* Customization & Support */}
      <section className="py-20 bg-[#000e3f]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl sm:text-4xl font-bold mb-12">
            We Handle Everything
          </h3>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <Shield className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">No IT Setup Required</h4>
              <p className="text-blue-200">We'll take care of all the tech setup for your school</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <MessageCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">24/7 Support</h4>
              <p className="text-blue-200">Facing any issue? We'll solve it immediately</p>
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
              <Zap className="w-12 h-12 text-purple-400 mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">Custom Features</h4>
              <p className="text-blue-200">Need a special feature? We'll build it for your school</p>
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-2xl p-8 border border-blue-500/20">
            <p className="text-xl text-blue-100 italic">
              "Your success is our priority. We don't just provide software - we become your technology partner."
            </p>
          </div>
        </div>
      </section>

      {/* Join the Movement */}
      <section className="py-20 bg-gradient-to-r from-[#001454] to-[#000e3f]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl sm:text-4xl font-bold mb-6">
            Join the School Revolution
          </h3>
          <p className="text-xl text-blue-200 mb-8">
            Modern schools are already using digital diaries—don't fall behind.
          </p>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 mb-8">
            <div className="flex items-center justify-center mb-4">
              <Star className="w-6 h-6 text-yellow-400 mr-1" />
              <Star className="w-6 h-6 text-yellow-400 mr-1" />
              <Star className="w-6 h-6 text-yellow-400 mr-1" />
              <Star className="w-6 h-6 text-yellow-400 mr-1" />
              <Star className="w-6 h-6 text-yellow-400 mr-4" />
              <span className="text-sm text-blue-200">Join 100+ schools already using Techdairy</span>
            </div>
          </div>
          
          <a 
            href="https://wa.me/message/6ROBRBS4JHVMM1" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            <MessageCircle className="w-6 h-6 mr-3" />
            Book Free Demo
            <ArrowRight className="w-5 h-5 ml-2" />
          </a>
        </div>
      </section>

      {/* Community */}
      <section className="py-16 bg-[#000e3f]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-r from-green-500/10 to-cyan-500/10 rounded-2xl p-8 border border-green-500/20">
            <h4 className="text-2xl font-bold mb-4">
              Also Join Our Telugu AI Community
            </h4>
            <p className="text-blue-200 mb-6">
              Connect with other educators and explore the future of AI in education
            </p>
            <a 
              href="https://chat.whatsapp.com/KCOyDJiw2DNCjpIx8epBky?mode=ac_t" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-green-500 to-cyan-500 hover:from-green-600 hover:to-cyan-600 text-white font-semibold rounded-full transition-all duration-300"
            >
              <Users className="w-5 h-5 mr-2" />
              Join AI Community
              <ExternalLink className="w-4 h-4 ml-2" />
            </a>
          </div>
        </div>
      </section>

      {/* Testimonial Placeholder */}
      <section className="py-20 bg-gradient-to-b from-[#000e3f] to-[#001454]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">What Schools Are Saying</h3>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 text-center">
            <div className="flex justify-center mb-4">
              <Star className="w-6 h-6 text-yellow-400" />
              <Star className="w-6 h-6 text-yellow-400" />
              <Star className="w-6 h-6 text-yellow-400" />
              <Star className="w-6 h-6 text-yellow-400" />
              <Star className="w-6 h-6 text-yellow-400" />
            </div>
            <blockquote className="text-xl text-blue-100 mb-6 italic">
              "Techdairy transformed our school communication. Parents love the instant updates, teachers save hours daily, and students never miss homework anymore."
            </blockquote>
            <div className="text-blue-200">
              <p className="font-semibold">Principal Name</p>
              <p className="text-sm">ABC International School</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Founder */}
      <section className="py-20 bg-[#001454]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Meet the Founder</h3>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
            <div className="flex flex-col md:flex-row items-center text-center md:text-left">
              <div className="w-32 h-32 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mb-6 md:mb-0 md:mr-8">
                <User className="w-16 h-16 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-2xl font-bold mb-2">KATKAM NAMRITH</h4>
                <p className="text-blue-200 mb-4">
                  A visionary student entrepreneur building smart education solutions to transform how schools operate in the digital age.
                </p>
                <a 
                  href="https://www.linkedin.com/in/katkam-namrith-25b091354" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-300"
                >
                  Connect on LinkedIn
                  <ExternalLink className="w-4 h-4 ml-2" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Footer */}
      <section className="py-20 bg-gradient-to-r from-[#000e3f] via-[#001454] to-[#000e3f]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-4xl sm:text-5xl font-bold mb-6">
            Digitize your school with Techdairy today
          </h3>
          <p className="text-xl text-blue-200 mb-8">
            Join the future of education. Your students, teachers, and parents will thank you.
          </p>
          
          <a 
            href="https://wa.me/message/6ROBRBS4JHVMM1" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center px-10 py-5 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold rounded-full text-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl mb-8"
          >
            <MessageCircle className="w-7 h-7 mr-3" />
            Book Free Demo
            <ArrowRight className="w-6 h-6 ml-3" />
          </a>
          
          <div className="text-center text-blue-300 text-sm">
            <p>© 2024 Techdairy. All rights reserved.</p>
            <p className="mt-2">Transforming education, one school at a time.</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;